(function () {
  function escapeHtml(value) {
    return String(value)
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;")
      .replace(/'/g, "&#39;");
  }

  function item(label, href, active, external = false) {
    const cls = active ? "menu-link active" : "menu-link";
    const attrs = external ? ` target="_blank" rel="noopener noreferrer"` : "";
    return `<a class="${escapeHtml(cls)}" href="${escapeHtml(href)}"${attrs}>${escapeHtml(label)}</a>`;
  }

  function mount(targetId, activeItem) {
    const root = document.getElementById(targetId);
    if (!root) return;

    root.innerHTML = `
      <header class="site-header">
        <div class="brand-stack">
          <div class="brand-top">
            <img class="brand-logo-dr" src="/assets/brand/dr-logo-header.png" alt="DeciRepo logo" width="43" height="40" />
            <span class="brand-registry">DeciRepo</span>
          </div>
        <div class="brand-subline">
          <span class="brand-sub">Powered by DLX deterministic engine</span>
        </div>
        </div>
        <nav class="header-menu" aria-label="Primary">
          ${item("Home", "/", activeItem === "repository" || activeItem === "home")}
          ${item("About", "/pages/about.html", activeItem === "about")}
          ${item("Cases", "/pages/cases.html", activeItem === "cases")}
          ${item("Proof", "/pages/proof.html", activeItem === "proof")}
          ${item("Request Pilot", "/pages/billing.html#request-pilot", activeItem === "request-pilot" || activeItem === "billing")}
          ${item("DLX Site", "https://indrasnet.ee/", false, true)}
        </nav>
      </header>
      <div class="header-divider"></div>
    `;
  }

  window.DeciRepoHeader = { mount, escapeHtml };
})();
